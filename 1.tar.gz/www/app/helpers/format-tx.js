import Ember from 'ember';

export function formatTx(value) {
  return value[0].substring(3, 20) + "..." + value[0].substring(3,20);
}

export default Ember.Helper.helper(formatTx);
